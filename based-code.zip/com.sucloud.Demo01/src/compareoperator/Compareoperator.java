package compareoperator;

public class Compareoperator {
    public static void main(String[] args) {
        int a = 1;
        int b = 1;
        int c = 2;
        //输出的结果都是boolean类型的
        System.out.println(a == b);
        System.out.println(a == c);

    }
}
